import { Component } from '@angular/core';

@Component({
  selector: 'mw-app',
  template: '<h1>My App</h1>'
})
export class AppComponent {}
